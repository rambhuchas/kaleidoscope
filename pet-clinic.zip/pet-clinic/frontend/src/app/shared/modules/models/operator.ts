
export interface Operator {
  id: number;
  name: string;
  address: string;
  city: string;
  telephone: string;
  country: string;
  establishedDate: Date;
}
