import { ProductId } from './productid';

export interface Channel {
  channelId: number;
  channelDesc: String;
}
