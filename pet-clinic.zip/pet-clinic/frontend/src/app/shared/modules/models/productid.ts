
export interface ProductId {

  pid: string;

  serviceId: string;

}
