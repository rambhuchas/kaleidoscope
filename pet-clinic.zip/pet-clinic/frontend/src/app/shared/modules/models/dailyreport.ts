export interface DailyReport {
  subRevenue: number;
  subretryRevenue: number;
  renewalRevenue: number;
  totalRevenue: number;
  date: Date;
}
