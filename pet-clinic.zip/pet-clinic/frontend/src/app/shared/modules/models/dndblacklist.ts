export interface DndBlacklist {
    msisdn: string;
    createdDate: Date;
}
