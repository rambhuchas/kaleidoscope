jQuery(document).ready(function($) {
	'use strict';

	jQuery(window).load(function() {
		jQuery('#themeblossom_loading_screen').addClass('loaded');
	});
});